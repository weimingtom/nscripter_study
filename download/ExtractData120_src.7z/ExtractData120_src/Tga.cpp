
#include	"stdafx.h"
#include	"ExtractBase.h"
#include	"Image.h"
#include	"Tga.h"

//////////////////////////////////////////////////////////////////////////////////////////
//	�f�R�[�h

BOOL	CTga::Decode(
	CArcFile*			pclArc,							// �A�[�J�C�u
	const void*			pvSrc,							// TGA�f�[�^
	DWORD				dwSrcSize,						// TGA�f�[�^�T�C�Y
	const YCString&		rfclsFileLastName				// �t�@�C�����̖���
	)
{
	const BYTE*			pbtSrc = (const BYTE*) pvSrc;
	const STGAHeader*	psttgahSrc = (STGAHeader*) pvSrc;

	pbtSrc += sizeof(STGAHeader);
	dwSrcSize -= sizeof(STGAHeader);

	// ��

	YCMemory<BYTE>		clmbtSrc2;

	switch( psttgahSrc->btImageType )
	{
	case	9:
	case	10:
		// RLE���k

		DWORD				dwSrcSize2 = ((psttgahSrc->wWidth * (psttgahSrc->btDepth >> 3) + 3) & 0xFFFFFFFC) * psttgahSrc->wHeight;

		clmbtSrc2.resize( dwSrcSize2 );

		DecompRLE( &clmbtSrc2[0], dwSrcSize2, pbtSrc, dwSrcSize, psttgahSrc->btDepth );

		pbtSrc = &clmbtSrc2[0];
		dwSrcSize = dwSrcSize2;

		break;
	}

	CImage				clImage;

	if( psttgahSrc->btDepth == 0 )
	{
		clImage.Init( pclArc, psttgahSrc->wWidth, psttgahSrc->wHeight, 32, NULL, 0, rfclsFileLastName );
		clImage.WriteReverse( pbtSrc, dwSrcSize );
		clImage.Close();
	}
	else
	{
		clImage.Init( pclArc, psttgahSrc->wWidth, psttgahSrc->wHeight, psttgahSrc->btDepth, NULL, 0, rfclsFileLastName );
		clImage.Write( pbtSrc, dwSrcSize );
		clImage.Close();
	}

	return	TRUE;
}

//////////////////////////////////////////////////////////////////////////////////////////
//	���kTGA�̉�

BOOL	CTga::Decomp(
	void*				pvDst,							// �i�[��
	DWORD				dwDstSize,						// �i�[��T�C�Y
	const void*			pvSrc,							// ���kTGA
	DWORD				dwSrcSize						// ���kTGA�T�C�Y
	)
{
	BYTE*				pbtDst = (BYTE*) pvDst;
	const BYTE*			pbtSrc = (const BYTE*) pvSrc;
	const STGAHeader*	psttgahSrc = (STGAHeader*) pvSrc;

	pbtSrc += sizeof(STGAHeader);
	dwSrcSize -= sizeof(STGAHeader);

	// ��

	switch( psttgahSrc->btDepth )
	{
	case	9:
	case	10:
		// RLE

		DecompRLE( pbtDst, dwDstSize, pbtSrc, dwSrcSize, psttgahSrc->btDepth );
		break;

	default:
		// �����k

		memcpy( pbtDst, pbtSrc, dwSrcSize );
	}

	return	TRUE;
}

//////////////////////////////////////////////////////////////////////////////////////////
//	RLE��

BOOL	CTga::DecompRLE(
	void*				pvDst,							// �i�[��
	DWORD				dwDstSize,						// �i�[��T�C�Y
	const void*			pvSrc,							// ���k�f�[�^
	DWORD				dwSrcSize,						// ���k�f�[�^�T�C�Y
	BYTE				wBpp							// �r�b�g��
	)
{
	const BYTE*			pbtSrc = (const BYTE*) pvSrc;
	BYTE*				pbtDst = (BYTE*) pvDst;
	DWORD				dwSrcPtr = 0;
	DWORD				dwDstPtr = 0;
	WORD				wByteCount = (wBpp >> 3);

	while( (dwSrcPtr < dwSrcSize) && (dwDstPtr < dwDstSize) )
	{
		DWORD				dwLength = pbtSrc[dwSrcPtr++];

		if( dwLength & 0x80 )
		{
			dwLength = (dwLength & 0x7F) + 1;

			for( DWORD i = 0 ; i < dwLength ; i++ )
			{
				memcpy( &pbtDst[dwDstPtr], &pbtSrc[dwSrcPtr], wByteCount );

				dwDstPtr += wByteCount;
			}

			dwSrcPtr += wByteCount;
		}
		else
		{
			dwLength++;

			dwLength *= wByteCount;

			memcpy( &pbtDst[dwDstPtr], &pbtSrc[dwSrcPtr], dwLength );

			dwSrcPtr += dwLength;
			dwDstPtr += dwLength;
		}

		if( memcmp( &pbtSrc[dwSrcPtr + 8], "TRUEVISION-XFILE", 16 ) == 0 )
		{
			// �I�[

			break;
		}
	}

	return	TRUE;
}
