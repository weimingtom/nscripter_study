
#include	"stdafx.h"
#include	"res/ResExtractData.h"
#include	"Common.h"
#include	"Ctrl/Button.h"
#include	"Ctrl/EditBox.h"
#include	"Ctrl/Label.h"
#include	"Ctrl/GroupBox.h"
#include	"Ctrl/RadioBtn.h"
#include	"Ctrl/UpDown.h"
#include	"Dialog/FolderDialog.h"
#include	"Reg.h"
#include	"Susie.h"
#include	"SusieListView.h"
#include	"Option.h"

typedef int (WINAPI* ConfigurationDlgProc)(HWND, int);

SOption COption::m_option;
SOption COption::m_option_tmp;
std::vector<YCString> COption::m_SearchFiles;
CMainListView* COption::m_pListView;
CSearchToolBar* COption::m_pToolBar;
HWND COption::m_hDlg = NULL;
HWND COption::m_hParentWnd = NULL;

void COption::Init(CSearchToolBar& toolbar, CMainListView& listview)
{
	m_pToolBar = &toolbar;
	m_pListView = &listview;

	std::vector<YCString>& SearchFiles = m_SearchFiles;
	SearchFiles.push_back(_T("AHX"));
	SearchFiles.push_back(_T("BMP"));
	SearchFiles.push_back(_T("JPG"));
	SearchFiles.push_back(_T("MID"));
	SearchFiles.push_back(_T("MPG"));
	SearchFiles.push_back(_T("OGG"));
	SearchFiles.push_back(_T("PNG"));
	SearchFiles.push_back(_T("WAV"));
	SearchFiles.push_back(_T("WMV"));

	LoadIni();

	// Susie�v���O�C���ǂݍ���
	if( m_option.bSusieUse )
	{
		CSusie susie;
		susie.LoadSpi(m_option.SusieDir);
	}
}

void COption::LoadIni()
{
	SOption* pOption = &m_option;

	YCIni				clIni( SBL_STR_INI_EXTRACTDATA );
	CReg				clReg;

	clIni.SetSection( _T("Option") );

	// ���X�g�̔w�i�F

	clIni.SetKey( _T("ListBkColor") );
	clIni.ReadStr( pOption->szListBkColor, sizeof(pOption->szListBkColor), _T("FFFFFF") );
	pOption->ListBkColor = _tcstol( pOption->szListBkColor, NULL, 16 );

	// ���X�g�̕����F

	clIni.SetKey( _T("ListTextColor") );
	clIni.ReadStr( pOption->szListTextColor, sizeof(pOption->szListTextColor), _T("000000") );
	pOption->ListTextColor = _tcstol( pOption->szListTextColor, NULL, 16 );

	// OGG�̌������x���グ�邩�ǂ����̐ݒ�

	clIni.SetKey( _T("HighSearchOgg") );
	clIni.ReadDec( &pOption->bHighSearchOgg, TRUE );

	// �t�H���_���ƒ��o���邩�ǂ����̐ݒ�

	clIni.SetKey( _T("ExtFolder") );
	clIni.ReadDec( &pOption->bCreateFolder, TRUE );

	// OGG���o����CRC���C�����邩�ǂ����̐ݒ�

	clIni.SetKey( _T("OggCRC") );
	clIni.ReadDec( &pOption->bFixOgg, FALSE );

	// �ȈՕ����@�\��L���ɂ��邩�ǂ����̐ݒ�

	clIni.SetKey( _T("EasyDecrypt") );
	clIni.ReadDec( &pOption->bEasyDecrypt, FALSE );

	// �X�N���v�g�̊g���q��ύX���邩�ǂ����̐ݒ�

	clIni.SetKey( _T("RenameScriptExt") );
	clIni.ReadDec( &pOption->bRenameScriptExt, TRUE );

	// �o�͉摜�`���̐ݒ�

	clIni.SetKey( _T("DstBMP") );
	clIni.ReadDec( &pOption->bDstBMP, TRUE );
	clIni.SetKey( _T("DstPNG") );
	clIni.ReadDec( &pOption->bDstPNG, FALSE );

	// PNG���k���x���̐ݒ�

	clIni.SetKey( _T("CmplvPng") );
	clIni.ReadDec( &pOption->CmplvPng, (DWORD) 1 );

	// ���u�����h���s�����ǂ����̐ݒ�

	clIni.SetKey( _T("AlphaBlend") );
	clIni.ReadDec( &pOption->bAlphaBlend, FALSE );

	// ���u�����h�̍������̐ݒ�

	clIni.SetKey( _T("FastAlphaBlend") );
	clIni.ReadDec( &pOption->bFastAlphaBlend, FALSE );

	// ���u�����h���s���Ƃ��̔w�i�F

	clIni.SetKey( _T("BG_RGB") );
	clIni.ReadStr( pOption->szBgRGB, sizeof(pOption->szBgRGB), _T("FFFFFF") );
	pOption->BgRGB = _tcstol( pOption->szBgRGB, NULL, 16 );

	// �o�͐�

	clIni.SetKey( _T("SaveMethodSel") );
	clIni.ReadDec( &pOption->bSaveSel, TRUE );
	clIni.SetKey( _T("SaveMethodSrc") );
	clIni.ReadDec( &pOption->bSaveSrc, FALSE );
	clIni.SetKey( _T("SaveMethodDir") );
	clIni.ReadDec( &pOption->bSaveDir, FALSE );

	// �Œ�o�̓t�H���_

	TCHAR				szDesktopPath[_MAX_DIR];

	::SHGetSpecialFolderPath( NULL, szDesktopPath, CSIDL_DESKTOPDIRECTORY, FALSE );

	clIni.SetKey( _T("SaveDir") );
	clIni.ReadStr( pOption->SaveDir, szDesktopPath );

	// �o�b�t�@�T�C�Y

	clIni.SetKey( _T("BufSize") );
	clIni.ReadDec( &pOption->BufSize, (DWORD) 64 );

	// �e���|�����t�H���_

	TCHAR				szTmpDir[_MAX_DIR];
	TCHAR				szTmpDirLong[_MAX_DIR];

	::GetTempPath( _countof(szTmpDir), szTmpDir );
	::GetLongPathName( szTmpDir, szTmpDirLong, 256 );
	PathAppend( szTmpDirLong, _T("ExtractData") );

	clIni.SetKey( _T("TmpDir") );
	clIni.ReadStr( pOption->TmpDir, szTmpDirLong );

	// Susie�̐ݒ�

	clIni.SetSection( _T("Susie") );

	// Susie�v���O�C�����g�p����

	clIni.SetKey( _T("SusieUse") );
	clIni.ReadDec( &pOption->bSusieUse, FALSE );

	// Susie�t�H���_

	YCString			clsPathToSusieFolder;

	clReg.GetValue( clsPathToSusieFolder, _T("HKEY_CURRENT_USER\\Software\\Takechin\\Susie\\Plug-in"), _T("Path") );

	clIni.SetKey( _T("SusieDir") );
	clIni.ReadStr( pOption->SusieDir, clsPathToSusieFolder );

	// Susie�v���O�C����D�悷��

	clIni.SetKey( _T("SusieFirst") );
	clIni.ReadDec( &pOption->bSusieFirst, FALSE );

	// ��������t�@�C���̐ݒ�

	clIni.SetSection( _T("Search") );

	for( size_t i = 0 ; i < m_SearchFiles.size() ; i++ )
	{
		BOOL				bSearch;

		clIni.SetKey( m_SearchFiles[i] );
		clIni.ReadDec( &bSearch, TRUE );

		pOption->bSearch.push_back( bSearch );
	}
}

void COption::SaveIni()
{
	SOption& pOption = m_option;

	YCIni				clIni( SBL_STR_INI_EXTRACTDATA );

	clIni.SetSection( _T("Option") );

	// ���X�g�̔w�i�F

	clIni.SetKey( _T("ListBkColor") );
	clIni.WriteHex( pOption.ListBkColor, 6 );

	// ���X�g�̕����F

	clIni.SetKey( _T("ListTextColor") );
	clIni.WriteHex( pOption.ListTextColor, 6 );

	// OGG�̌������x���グ��

	clIni.SetKey( _T("HighSearchOgg") );
	clIni.WriteDec( pOption.bHighSearchOgg );

	// �t�H���_���ƒ��o����

	clIni.SetKey( _T("ExtFolder") );
	clIni.WriteDec( pOption.bCreateFolder );

	// OGG���o����CRC���C��

	clIni.SetKey( _T("OggCRC") );
	clIni.WriteDec( pOption.bFixOgg );

	// �ȈՕ����@�\��L���ɂ���

	clIni.SetKey( _T("EasyDecrypt") );
	clIni.WriteDec( pOption.bEasyDecrypt );

	// �X�N���v�g�̊g���q��ύX���邩�ǂ����̐ݒ�

//	clIni.SetKey( _T("RenameScriptExt") );
//	clIni.WriteDec( pOption.bRenameScriptExt );

	// �o�͉摜�`��

	clIni.SetKey( _T("DstBMP") );
	clIni.WriteDec(pOption.bDstBMP );
	clIni.SetKey( _T("DstPNG") );
	clIni.WriteDec( pOption.bDstPNG );

	// PNG���k���x��

	clIni.SetKey( _T("CmplvPng") );
	clIni.WriteDec( pOption.CmplvPng );

	// ���u�����h���s��

	clIni.SetKey( _T("AlphaBlend") );
	clIni.WriteDec( pOption.bAlphaBlend );

	// ���u�����h�̍������̐ݒ�

	clIni.SetKey( _T("FastAlphaBlend") );
	clIni.WriteDec( pOption.bFastAlphaBlend );

	// ���u�����h���s���Ƃ��̔w�i�F

	clIni.SetKey( _T("BG_RGB") );
	clIni.WriteHex( pOption.BgRGB, 6 );

	// �o�͐�

	clIni.SetKey( _T("SaveMethodSel") );
	clIni.WriteDec( pOption.bSaveSel );
	clIni.SetKey( _T("SaveMethodSrc") );
	clIni.WriteDec( pOption.bSaveSrc );
	clIni.SetKey( _T("SaveMethodDir") );
	clIni.WriteDec( pOption.bSaveDir );

	// �Œ�o�̓t�H���_

	clIni.SetKey( _T("SaveDir") );
	clIni.WriteStr( pOption.SaveDir );

	// �o�b�t�@�T�C�Y

	clIni.SetKey( _T("BufSize") );
	clIni.WriteDec( pOption.BufSize );

	// �e���|�����t�H���_

	clIni.SetKey( _T("TmpDir") );
	clIni.WriteStr( pOption.TmpDir );

	// Susie�̐ݒ�

	clIni.SetSection( _T("Susie") );

	// Susie�v���O�C�����g�p����

	clIni.SetKey( _T("SusieUse") );
	clIni.WriteDec( pOption.bSusieUse );

	// Susie�t�H���_

	clIni.SetKey( _T("SusieDir") );
	clIni.WriteStr( pOption.SusieDir );

	// Susie�v���O�C����D�悷��

	clIni.SetKey( _T("SusieFirst") );
	clIni.WriteDec( pOption.bSusieFirst );

	// ��������t�@�C���̐ݒ�

	clIni.SetSection( _T("Search") );

	for( size_t i = 0 ; i < m_SearchFiles.size() ; i++ )
	{
		clIni.SetKey( m_SearchFiles[i] );
		clIni.WriteDec( pOption.bSearch[i] );
	}

	// Susie�v���O�C����ON/OFF�ݒ�ۑ�

	if( m_option.bSusieUse )
	{
		CSusie susie;
		susie.SaveSpi();
	}
}

void COption::DoModal(HWND hWnd)
{
	m_hDlg = CreateProp(hWnd);
}

HWND COption::CreateProp(HWND hWnd)
{
	m_hParentWnd = hWnd;
	HINSTANCE hInst = (HINSTANCE)GetWindowLongPtr(hWnd, GWLP_HINSTANCE);

	PROPSHEETPAGE psp;
	HPROPSHEETPAGE hpsp[3];
	psp.dwSize = sizeof(PROPSHEETPAGE);
	psp.dwFlags = PSP_USETITLE;
	psp.hInstance = hInst;
	psp.lParam = (LPARAM)this;
	psp.pszTemplate = _T("OPTION");

	psp.pszTitle = _T("��{�ݒ�");
	psp.pfnDlgProc = (DLGPROC)StdProc;
	hpsp[0] = CreatePropertySheetPage(&psp);
	psp.pszTitle = _T("���o�ݒ�");
	psp.pfnDlgProc = (DLGPROC)ExtractProc;
	hpsp[1] = CreatePropertySheetPage(&psp);
	psp.pszTitle = _T("Susie�v���O�C��");
	psp.pfnDlgProc = (DLGPROC)SusieProc;
	hpsp[2] = CreatePropertySheetPage(&psp);

	PROPSHEETHEADER psh;
	memset(&psh, 0, sizeof(PROPSHEETHEADER));
	psh.dwSize = sizeof(PROPSHEETHEADER);
	psh.dwFlags = PSH_USECALLBACK;
	psh.hInstance = hInst;
	psh.hwndParent = hWnd;
	psh.nPages = 3;
	psh.phpage = hpsp;
	psh.pszCaption = _T("ExtractData");
	psh.pfnCallback = (PFNPROPSHEETCALLBACK)PropSheetProc;

	return (HWND)PropertySheet(&psh);
}

int COption::PropSheetProc(HWND hWnd, UINT msg, LPARAM lParam)
{
	switch (msg) {
		case PSCB_INITIALIZED:
		{
			m_option_tmp = m_option;
			CSusie susie;
			susie.Init();
			LONG style = GetWindowLongPtr(hWnd, GWL_EXSTYLE);
			SetWindowLongPtr(hWnd, GWL_EXSTYLE, style & ~WS_EX_CONTEXTHELP);
			break;
		}
	}

	return FALSE;
}

LRESULT COption::StdProc(HWND hWnd, UINT msg, WPARAM wp, LPARAM lp)
{
	COption* pThis = (COption*)lp;

	static SOption* pOption = &m_option_tmp;

	// ���X�g�r���[�ݒ�
	static CGroupBox ListGroup;
	static CLabel ListLabelBk, ListLabelText;
	static CEditBox ListEditBk, ListEditText;
	// �����ݒ�
	static std::vector<YCString>& SearchCheckText = m_SearchFiles;
	static std::vector<CCheckBox> SearchCheck(SearchCheckText.size());
	static int SearchCheckNum = SearchCheckText.size();
	static CButton SearchBtn[2];
	static CGroupBox SearchGroup;
	// �������x
	static CGroupBox HighSearchGroup;
	static CCheckBox HighSearchCheckOgg;

	switch (msg) {
		case WM_INITDIALOG:
		{
			CWindowBase::Init(::GetParent(hWnd));

			UINT ID = 10000;
			int x = 10, y = 0, xx = 15;

			// ���X�g�r���[�ݒ�
			ListGroup.Create(hWnd, _T("���X�g�̐ݒ�"), ID++, x, y += 20, 470, 75);
			ListLabelBk.Create(hWnd, _T("�w�i�F"), ID++, x + xx, y += 24, 50, 20);
			ListEditBk.Create(hWnd, pOption->szListBkColor, ID++, x + xx + 50, y - 4, 70, 22);
			ListEditBk.SetLimit(6);
			ListLabelText.Create(hWnd, _T("�����F"), ID++, x + xx, y += 24, 50, 20);
			ListEditText.Create(hWnd, pOption->szListTextColor, ID++, x + xx + 50, y - 4, 70, 22);
			ListEditText.SetLimit(6);

			// �����ݒ�
			SearchGroup.Create(hWnd, _T("��������t�@�C��"), ID++, x, y += 40, 470, 100);
			//y += 20;
			for (int i = 0, xxx = 0; i < SearchCheckNum; i++, xxx += 55) {
				if ((i % 8) == 0)
					xxx = 0, y += 20;
				SearchCheck[i].Create(hWnd, SearchCheckText[i], ID++, x + xx + xxx, y, 50, 20);
				SearchCheck[i].SetCheck(pOption->bSearch[i]);
			}
			SearchBtn[0].Create(hWnd, _T("���ׂđI��"), ID++, 305, y += 30, 80, 20);
			SearchBtn[1].Create(hWnd, _T("�I������"),   ID++, 385, y, 80, 20);

			// �������x�ݒ�
			HighSearchGroup.Create(hWnd, _T("�������x"), ID++, x, y += 40, 470, 50);
			HighSearchCheckOgg.Create(hWnd, _T("OGG�̌������x���グ��"), ID++, x + xx, y += 20, 160, 20);
			HighSearchCheckOgg.SetCheck(pOption->bHighSearchOgg);

			break;
		}

		case WM_COMMAND:
			// �����t�@�C���`�F�b�N�{�b�N�X
			if (LOWORD(wp) >= SearchCheck[0].GetID() && LOWORD(wp) <= SearchCheck[SearchCheckNum-1].GetID()) {
				int nNumber = LOWORD(wp) - SearchCheck[0].GetID();
				pOption->bSearch[nNumber] ^= 1;
				SearchCheck[nNumber].SetCheck(pOption->bSearch[nNumber]);
				PropSheet_Changed(::GetParent(hWnd), hWnd);
				break;
			}
			// ���ׂđI��
			if (LOWORD(wp) == SearchBtn[0].GetID()) {
				for (int i = 0; i < SearchCheckNum; i++) {
					pOption->bSearch[i] = TRUE;
					SearchCheck[i].SetCheck(pOption->bSearch[i]);
				}
				PropSheet_Changed(::GetParent(hWnd), hWnd);
				break;
			}
			// �I������
			if (LOWORD(wp) == SearchBtn[1].GetID()) {
				for (int i = 0; i < SearchCheckNum; i++) {
					pOption->bSearch[i] = FALSE;
					SearchCheck[i].SetCheck(pOption->bSearch[i]);
				}
				PropSheet_Changed(::GetParent(hWnd), hWnd);
				break;
			}
			if (LOWORD(wp) == HighSearchCheckOgg.GetID()) {
				PropSheet_Changed(::GetParent(hWnd), hWnd);
				break;
			}
			// �G�f�B�b�g�{�b�N�X�̓��e���ύX���ꂽ
			if (HIWORD(wp) == EN_CHANGE) {
				PropSheet_Changed(::GetParent(hWnd), hWnd);
				break;
			}
			break;

		case WM_NOTIFY:
		{
			LPNMHDR pHdr = (LPNMHDR)lp;
			switch (pHdr->code) {
				// OK/�K�p, �^�u�ړ�
				case PSN_APPLY:
				case PSN_KILLACTIVE:
					ListEditBk.GetText(&pOption->ListBkColor, TRUE);
					_stprintf(pOption->szListBkColor, _T("%06x"), pOption->ListBkColor);
					ListEditText.GetText(&pOption->ListTextColor, TRUE);
					_stprintf(pOption->szListTextColor, _T("%06x"), pOption->ListTextColor);

					pOption->bHighSearchOgg = HighSearchCheckOgg.GetCheck();
					// OK/�K�p
					if (pHdr->code == PSN_APPLY)
						Apply();
					return TRUE;
			}
			break;
		}
	}

	return FALSE;
}

LRESULT COption::ExtractProc(HWND hWnd, UINT msg, WPARAM wp, LPARAM lp)
{
	COption* pThis = (COption*)lp;

	static CError error;
	static CFolderDialog FolderDlg;
	static SOption* pOption = &m_option_tmp;

	// ���o�ݒ�

	static YCString ExtractCheckText[] =
	{
		_T("�t�H���_���ƒ��o����"), _T("OGG�t�@�C����CRC���C������"), _T("�ȈՕ����@�\��L���ɂ���")
	};

	static BOOL* ExtractCheckFlag[] =
	{
		&pOption->bCreateFolder, &pOption->bFixOgg, &pOption->bEasyDecrypt, &pOption->bRenameScriptExt
	};

	static int ExtractCheckNum = _countof( ExtractCheckText );
	static std::vector<CCheckBox> ExtractCheck( ExtractCheckNum );
	static CCheckBox ExtractCheckAlpha, ExtractCheckFastAlpha;
	static CLabel ExtractLabelImage, ExtractLabelPng, ExtractLabelAlpha, ExtractLabelSave, ExtractLabelBuf, ExtractLabelTmp;
	static CRadioBtn ExtractRadioImage, ExtractRadioSave;
	static CUpDown ExtractUpDownPng;
	static CEditBox ExtractEditSusie, ExtractEditPng, ExtractEditAlpha, ExtractEditSave, ExtractEditBuf, ExtractEditTmp;
	static CButton ExtractBtnSusie, ExtractBtnSave, ExtractBtnTmp;
	static CGroupBox ExtractGroupImage, ExtractGroupSave;

	switch (msg) {
		case WM_INITDIALOG:
		{
			UINT ID = 10000;
			int x = 10, y = 0, xx = 15;

			// ���o�ݒ�

			for( int i = 0 ; i < ExtractCheckNum ; i++ )
			{
				ExtractCheck[i].Create( hWnd, ExtractCheckText[i], ID++, x, y += 20, 200, 20 );
				ExtractCheck[i].SetCheck( *ExtractCheckFlag[i] );
			}

			//

			int y_Image = y;
			ExtractGroupImage.Create(hWnd, _T("�o�͉摜�`��"), ID++, x, y_Image += 34, 190, 130);
			ExtractRadioImage.Close(); // static�ɂ��Ă邹�����f�X�g���N�^���Ă΂ꂸ�O��̂������Ȃ��̂ŃN���[�Y
			ExtractRadioImage.Create(hWnd, _T("BMP"), ID++, x + xx, y_Image += 18, 50, 20);
			ExtractRadioImage.Create(hWnd, _T("PNG"), ID++, x + xx, y_Image += 20, 50, 20);
			ExtractRadioImage.SetCheck(0, pOption->bDstBMP);
			ExtractRadioImage.SetCheck(1, pOption->bDstPNG);
			ExtractLabelPng.Create(hWnd, _T("���k���x��"), ID++, x + xx + 50, y_Image + 3, 60, 20);
			ExtractEditPng.Create(hWnd, _T(""), ID++, x + xx + 110, y_Image, 40, 22);
			ExtractEditPng.SetLimit(1);
			ExtractUpDownPng.Create(hWnd, ExtractEditPng.GetCtrlHandle(), pOption->CmplvPng, ID++, 9, 0);

			//

			ExtractCheckAlpha.Create(hWnd, _T("���u�����h���s��"), ID++, x + xx, y_Image += 22, 100, 20);
			ExtractCheckAlpha.SetCheck(pOption->bAlphaBlend);
			ExtractLabelAlpha.Create(hWnd, _T("�w�i�F"), ID++, x + xx * 2, y_Image += 24, 40, 20);
			ExtractEditAlpha.Create(hWnd, pOption->szBgRGB, ID++, x + xx * 2 + 50, y_Image - 4, 100, 22);
			ExtractEditAlpha.SetLimit(6);
			ExtractEditAlpha.Enable(pOption->bAlphaBlend);

			ExtractCheckFastAlpha.Create( hWnd, _T("�����ɏ�������"), ID++, x + xx * 2, y_Image += 20, 120, 20);
			ExtractCheckFastAlpha.SetCheck( pOption->bFastAlphaBlend );
			ExtractCheckFastAlpha.Enable( pOption->bAlphaBlend );

			//

			int x_Save = x + 200;
			int y_Save = y;

			ExtractGroupSave.Create(hWnd, _T("�o�͐�"), ID++, x_Save, y_Save += 34, 280, 110);
			ExtractRadioSave.Close(); // static�ɂ��Ă邹�����f�X�g���N�^���Ă΂ꂸ�O��̂������Ȃ��̂ŃN���[�Y
			ExtractRadioSave.Create(hWnd, _T("����w�肷��"), ID++, x_Save + xx, y_Save += 18, 200, 20);
			ExtractRadioSave.Create(hWnd, _T("���͐�Ɠ����t�H���_"), ID++, x_Save + xx, y_Save += 20, 200, 20);
			ExtractRadioSave.Create(hWnd, _T("���L�̃t�H���_"), ID++, x_Save + xx, y_Save += 20, 200, 20);
			ExtractRadioSave.SetCheck(0, pOption->bSaveSel);
			ExtractRadioSave.SetCheck(1, pOption->bSaveSrc);
			ExtractRadioSave.SetCheck(2, pOption->bSaveDir);
			ExtractEditSave.Create(hWnd, pOption->SaveDir, ID++, x_Save + xx * 2, y_Save += 20, 200, 22);
			ExtractEditSave.Enable(pOption->bSaveDir);
			ExtractBtnSave.Create(hWnd, _T("�Q��"), ID++, x_Save + xx * 2 + 200, y_Save + 1, 40, 20);
			ExtractBtnSave.Enable(pOption->bSaveDir);

			//

			y = (y_Image > y_Save) ? y_Image : y_Save;
			ExtractLabelBuf.Create(hWnd, _T("�o�b�t�@�T�C�Y(KB)"), ID++, x, y += 44, 100, 20);
			ExtractEditBuf.Create(hWnd, pOption->BufSize, ID++, x + 100, y - 4, 110, 22);

			//

			ExtractLabelTmp.Create(hWnd, _T("�e���|�����t�H���_"), ID++, x, y += 24, 100, 20);
			ExtractEditTmp.Create(hWnd, pOption->TmpDir, ID++, x + 100, y - 4, 200, 22);
			ExtractBtnTmp.Create(hWnd, _T("�Q��"), ID++, x + 300, y - 3, 40, 20);

			break;
		}

		case WM_COMMAND:
			// ��̃`�F�b�N�{�b�N�X
			if (LOWORD(wp) >= ExtractCheck[0].GetID() && LOWORD(wp) <= ExtractCheck[ExtractCheckNum-1].GetID()) {
				PropSheet_Changed(::GetParent(hWnd), hWnd);
				break;
			}
			// ���u�����h�`�F�b�N�{�b�N�X
			if (LOWORD(wp) == ExtractCheckAlpha.GetID()) {
				ExtractEditAlpha.Enable(ExtractCheckAlpha.GetCheck());
				ExtractCheckFastAlpha.Enable( ExtractCheckAlpha.GetCheck() );
				PropSheet_Changed(::GetParent(hWnd), hWnd);
				break;
			}
			// �o�͉摜�`�����W�I�{�^��
			if (LOWORD(wp) >= ExtractRadioImage.GetID(0) && LOWORD(wp) <= ExtractRadioImage.GetID(1)) {
				PropSheet_Changed(::GetParent(hWnd), hWnd);
				break;
			}
			// �o�͐惉�W�I�{�^��
			if (LOWORD(wp) >= ExtractRadioSave.GetID(0) && LOWORD(wp) <= ExtractRadioSave.GetID(2)) {
				ExtractEditSave.Enable(ExtractRadioSave.GetCheck(2));
				ExtractBtnSave.Enable(ExtractRadioSave.GetCheck(2));
				PropSheet_Changed(::GetParent(hWnd), hWnd);
				break;
			}
			// �o�̓t�H���_�Q��
			if (LOWORD(wp) == ExtractBtnSave.GetID()) {
				TCHAR szSaveDir[_MAX_DIR];
				ExtractEditSave.GetText(szSaveDir, sizeof(szSaveDir));
				if (FolderDlg.DoModal(hWnd, _T("�o�̓t�H���_�I��"), szSaveDir) == TRUE)
					ExtractEditSave.SetText(szSaveDir);
				break;
			}
			// �e���|�����t�H���_�Q��
			if (LOWORD(wp) == ExtractBtnTmp.GetID()) {
				TCHAR szTmpDir[_MAX_DIR];
				ExtractEditTmp.GetText(szTmpDir, sizeof(szTmpDir));
				if (FolderDlg.DoModal(hWnd, _T("�e���|�����t�H���_�I��"), szTmpDir) == TRUE)
					ExtractEditTmp.SetText(szTmpDir);
				break;
			}
			// �G�f�B�b�g�{�b�N�X�̓��e���ύX���ꂽ
			if (HIWORD(wp) == EN_CHANGE) {
				PropSheet_Changed(::GetParent(hWnd), hWnd);
				break;
			}
			break;

		case WM_NOTIFY:
		{
			LPNMHDR pHdr = (LPNMHDR)lp;
			switch (pHdr->code) {
				// OK/�K�p, �^�u�ړ�
				case PSN_APPLY:
				case PSN_KILLACTIVE:
					// ���o�ݒ�
					for (int i = 0; i < (int)ExtractCheck.size(); i++)
						*ExtractCheckFlag[i] = ExtractCheck[i].GetCheck();
					//
					pOption->bDstBMP = ExtractRadioImage.GetCheck(0);
					pOption->bDstPNG = ExtractRadioImage.GetCheck(1);
					ExtractEditPng.GetText(&pOption->CmplvPng, FALSE);
					//
					pOption->bAlphaBlend = ExtractCheckAlpha.GetCheck();
					pOption->bFastAlphaBlend = ExtractCheckFastAlpha.GetCheck();
					ExtractEditAlpha.GetText(&pOption->BgRGB, TRUE);
					_stprintf(pOption->szBgRGB, _T("%06x"), pOption->BgRGB);
					//
					pOption->bSaveSel = ExtractRadioSave.GetCheck(0);
					pOption->bSaveSrc = ExtractRadioSave.GetCheck(1);
					pOption->bSaveDir = ExtractRadioSave.GetCheck(2);
					ExtractEditSave.GetText(pOption->SaveDir);
					//
					ExtractEditBuf.GetText(&pOption->BufSize, FALSE);
					//
					ExtractEditTmp.GetText(pOption->TmpDir);
					// OK/�K�p
					if (pHdr->code == PSN_APPLY)
						Apply();
					return TRUE;
			}
			break;
		}
	}

	return FALSE;
}

LRESULT COption::SusieProc(HWND hWnd, UINT msg, WPARAM wp, LPARAM lp)
{
	COption* pThis = (COption*)lp;

	static CError error;
	static CFolderDialog FolderDlg;
	static SOption* pOption = &m_option_tmp;

	static CCheckBox SusieCheckUse, SusieCheckFirst;
	static CLabel SusieLabelDir;
	static CEditBox SusieEditDir;
	static CButton SusieBtnDir, SusieBtnUpdate, SusieBtn[2];
	static CSusieListView SusieListView;
	static CSusie susie;

	switch (msg) {
		case WM_INITDIALOG:
		{
			UINT ID = 10000;
			int x = 10, y = 0, xx = 15;

			SusieCheckUse.Create(hWnd, _T("Susie�v���O�C�����g�p����"), ID++, x, y += 20, 200, 20);
			SusieCheckUse.SetCheck(pOption->bSusieUse);

			SusieLabelDir.Create(hWnd, _T("Susie�t�H���_"), ID++, x + xx, y += 24, 75, 20);
			SusieEditDir.Create(hWnd, pOption->SusieDir, ID++, x + xx + 75, y - 4, 200, 22);
			SusieEditDir.Enable(pOption->bSusieUse);
			SusieBtnDir.Create(hWnd, _T("�Q��"), ID++, x + xx + 275, y - 3, 40, 20);
			SusieBtnDir.Enable(pOption->bSusieUse);

			SusieCheckFirst.Create(hWnd, _T("Susie�v���O�C����D�悷��"), ID++, x + xx, y += 20, 200, 20);
			SusieCheckFirst.SetCheck(pOption->bSusieFirst);
			SusieCheckFirst.Enable(pOption->bSusieUse);

			SusieListView.Create(hWnd, *pOption, x + xx, y += 30, 445, 190);
			SusieListView.Close();
			SusieListView.Enable(pOption->bSusieUse);
			SusieListView.Show();

			SusieBtnUpdate.Create(hWnd, _T("�X�V"), ID++, x + 240, y += 200, 50, 20);
			SusieBtnUpdate.Enable(pOption->bSusieUse);
			SusieBtn[0].Create(hWnd, _T("���ׂ�ON"), ID++, x + 300, y, 80, 20);
			SusieBtn[0].Enable(pOption->bSusieUse);
			SusieBtn[1].Create(hWnd, _T("���ׂ�OFF"), ID++, x + 380, y, 80, 20);
			SusieBtn[1].Enable(pOption->bSusieUse);

			break;
		}

		case WM_COMMAND:
			// Susie�v���O�C�����g�p����
			if (LOWORD(wp) == SusieCheckUse.GetID()) {
				BOOL flag = SusieCheckUse.GetCheck();
				SusieEditDir.Enable(flag);
				SusieBtnDir.Enable(flag);
				SusieCheckFirst.Enable(flag);
				SusieListView.Enable(flag);
				SusieBtnUpdate.Enable(flag);
				SusieBtn[0].Enable(flag);
				SusieBtn[1].Enable(flag);
				PropSheet_Changed(::GetParent(hWnd), hWnd);
				// �`�F�b�N�{�b�N�X�̕\��/��\���؂�ւ��A�I����ԉ���
				pOption->bSusieUse = flag;
				SusieListView.SetItemSelAll(0);
				break;
			}
			// Susie�t�H���_�Q��
			if (LOWORD(wp) == SusieBtnDir.GetID()) {
				TCHAR szSusieDir[_MAX_DIR];
				SusieEditDir.GetText(szSusieDir, sizeof(szSusieDir));
				if (FolderDlg.DoModal(hWnd, _T("Susie�t�H���_�I��"), szSusieDir) == TRUE)
					SusieEditDir.SetText(szSusieDir);
			}
			// Susie�v���O�C����D�悷��
			if (LOWORD(wp) == SusieCheckFirst.GetID()) {
				PropSheet_Changed(::GetParent(hWnd), hWnd);
				break;
			}
			// �X�V
			if (LOWORD(wp) == SusieBtnUpdate.GetID()) {
				susie.LoadSpi(pOption->SusieDir);
				susie.Init();
				SusieListView.Show();
				SusieListView.Update();
				break;
			}
			// ���ׂ�ON
			if (LOWORD(wp) == SusieBtn[0].GetID()) {
				SusieListView.SetCheckAll(1);
				PropSheet_Changed(::GetParent(hWnd), hWnd);
				break;
			}
			// ���ׂ�OFF
			if (LOWORD(wp) == SusieBtn[1].GetID()) {
				SusieListView.SetCheckAll(0);
				PropSheet_Changed(::GetParent(hWnd), hWnd);
				break;
			}
			// �ݒ�
			if (LOWORD(wp) == IDM_SUSIE_SET) {
				SSusieInfo* pstSusieInfo = SusieListView.GetFocusSusieInfo();

				// ConfigurationDlg()�擾
				ConfigurationDlgProc	ConfigurationDlg = (ConfigurationDlgProc) pstSusieInfo->cllPlugin.GetProcAddress( _T("ConfigurationDlg") );

				if( ConfigurationDlg == NULL )
				{
					break;
				}

				// �ݒ�Ăяo��
				ConfigurationDlg( hWnd, 1 );

				break;
			}
			// �G�f�B�b�g�{�b�N�X�̓��e���ύX���ꂽ
			if (HIWORD(wp) == EN_CHANGE) {
				PropSheet_Changed(::GetParent(hWnd), hWnd);
				break;
			}
			break;

		case WM_NOTIFY:
		{
			LPNMHDR pHdr = (LPNMHDR)lp;

			switch (pHdr->code) {
				// OK/�K�p, �^�u�ړ�
				case PSN_APPLY:
				case PSN_KILLACTIVE:
					pOption->bSusieUse = SusieCheckUse.GetCheck();
					pOption->bSusieFirst = SusieCheckFirst.GetCheck();
					SusieEditDir.GetText(pOption->SusieDir);
					SusieListView.SaveIni();
					// OK/�K�p
					if (pHdr->code == PSN_APPLY) {
						BOOL bUpdate = (m_option.SusieDir == pOption->SusieDir) ? FALSE : TRUE;
						Apply();
						// Susie�t�H���_���ύX����Ă����Ƃ��̂݃v���O�C���Ď擾
						if (pOption->bSusieUse == TRUE && bUpdate == TRUE) {
							susie.LoadSpi(pOption->SusieDir);
							susie.Init();
							SusieListView.Show();
							SusieListView.Update();
						}
					}
					return TRUE;
				// �`�F�b�N����
				case NM_CLICK:
				case NM_DBLCLK:
					if (pHdr->idFrom == idsSusieList) {
						if (SusieListView.SetCheck() == TRUE)
							PropSheet_Changed(::GetParent(hWnd), hWnd);
						break;
					}
			}
			// ���X�g�r���[
			if (wp == idsSusieList) {
				LPNMLISTVIEW plv = (LPNMLISTVIEW)lp;
				switch (plv->hdr.code) {
					// �J�X�^���h���[
					case NM_CUSTOMDRAW:
						return SusieListView.CustomDraw((LPNMLVCUSTOMDRAW)lp);
					// �c�[���`�b�v�\��
					case LVN_GETINFOTIP:
						SusieListView.ShowTip((LPNMLVGETINFOTIP)lp);
						break;
					// �\��
					case LVN_GETDISPINFO:
						SusieListView.Show((NMLVDISPINFO*)lp);
						break;
				}
			}

			break;
		}

		case WM_MOUSEWHEEL:
		{
			POINT pos;
			GetCursorPos(&pos);
			HWND pWnd = WindowFromPoint(pos);
			if (pWnd == SusieListView.GetHandle())
				SendMessage(pWnd, WM_MOUSEWHEEL, wp, lp);
			break;
		}

		// �E�N���b�N���j���[
		case WM_CONTEXTMENU:
		{
			if (wp == (WPARAM)SusieListView.GetHandle())
				SusieListView.CreateMenu(lp);
			break;
		}
	}

	return FALSE;
}

void COption::Apply()
{
	// �ύX���ʂɔ��f
	CSusie susie;
	susie.Apply();

	// ini�ɕۑ�
	m_option = m_option_tmp;
	SaveIni();

	m_pListView->SetBkColor();
	m_pListView->SetTextColor();
	m_pListView->Update();

	m_pToolBar->SetCheckSearch();
}