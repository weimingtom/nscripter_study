#pragma once

class CReg {
public:
	BOOL GetValue(YCString& Value, LPCTSTR pKeyPath, LPCTSTR pKeyName);
};