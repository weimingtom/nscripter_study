#include "stdafx.h"
#include "res/ResExtractData.h"
#include "MainListView.h"

// ���C�����X�g�̒l���Z�b�g���郁�\�b�h
void CMainListView::Create(HWND hWnd, SOption& option)
{
	Init(hWnd, option);

	std::vector<LVCOLUMN> lvcols;
	LVCOLUMN lvcol;

	lvcol.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
	lvcol.fmt = LVCFMT_LEFT;
	lvcol.cx = 45;
	lvcol.pszText = _T("No.");
	lvcols.push_back(lvcol);

	lvcol.fmt = LVCFMT_LEFT;
	lvcol.cx = 215;
	lvcol.pszText = _T("File Name");
	lvcols.push_back(lvcol);

	lvcol.fmt = LVCFMT_RIGHT;
	lvcol.cx = 90;
	lvcol.pszText = _T("File Size");
	lvcols.push_back(lvcol);

	lvcol.fmt = LVCFMT_RIGHT;
	lvcol.cx = 105;
	lvcol.pszText = _T("Compressed Size");
	lvcols.push_back(lvcol);

	lvcol.fmt = LVCFMT_RIGHT;
	lvcol.cx = 75;
	lvcol.pszText = _T("File Format");
	lvcols.push_back(lvcol);

	lvcol.fmt = LVCFMT_LEFT;
	lvcol.cx = 85;
	lvcol.pszText = _T("Archive File");
	lvcols.push_back(lvcol);

	lvcol.fmt = LVCFMT_RIGHT;
	lvcol.cx = 100;
	lvcol.pszText = _T("Start Address");
	lvcols.push_back(lvcol);

	lvcol.fmt = LVCFMT_RIGHT;
	lvcol.cx = 100;
	lvcol.pszText = _T("End Address");
	lvcols.push_back(lvcol);

	HWND hList = CListView::Create(idsMainList, lvcols);
	SetBkColor();
	SetTextColor();
}

void CMainListView::Show()
{
	ListView_SetItemCountEx(m_hList, m_ent.size(), LVSICF_NOINVALIDATEALL);
}

void CMainListView::Show(NMLVDISPINFO* pstDispInfo)
{
	static std::vector<SFileInfo>&	rfEnt = m_ent;

	if( pstDispInfo->item.mask & LVIF_TEXT )
	{
		SFileInfo&			rfstFileInfo = rfEnt[pstDispInfo->item.iItem];
		int					nTextMax = (pstDispInfo->item.cchTextMax - 1 );

		switch( pstDispInfo->item.iSubItem )
		{
		case	0:
			// No.�\��

			_stprintf( pstDispInfo->item.pszText, _T("%6d."), (pstDispInfo->item.iItem + 1) );
			break;

		case	1:
			// �t�@�C�����\��

			//_tcscpy_s(pstDispInfo->item.pszText, pstDispInfo->item.cchTextMax-100, pEnt[pstDispInfo->item.iItem].name);
			lstrcpy( pstDispInfo->item.pszText, rfstFileInfo.name.Left( nTextMax ) );
//			pstDispInfo->item.pszText = rfEnt[pstDispInfo->item.iItem].name.GetBuffer( 0 );
			break;

		case	2:
			// �t�@�C���T�C�Y�\��

			lstrcpy( pstDispInfo->item.pszText, rfstFileInfo.sSizeOrg.Left( nTextMax ) );
//			pstDispInfo->item.pszText = rfEnt[pstDispInfo->item.iItem].sSizeOrg.GetBuffer( 0 );
			break;

		case	3:
			// ���k�t�@�C���T�C�Y�\��

			if( rfstFileInfo.sizeCmp != rfstFileInfo.sizeOrg )
			{
//				pstDispInfo->item.pszText = rfEnt[pstDispInfo->item.iItem].sSizeCmp.GetBuffer( 0 );
				lstrcpy( pstDispInfo->item.pszText, rfstFileInfo.sSizeCmp.Left( nTextMax ) );
			}
			break;

		case	4:
			// �t�@�C���t�H�[�}�b�g�\��

			lstrcpy( pstDispInfo->item.pszText, rfstFileInfo.format.Left( nTextMax ) );
//			pstDispInfo->item.pszText = rfEnt[pstDispInfo->item.iItem].format.GetBuffer( 0 );
			break;

		case	5:
			// �A�[�J�C�u�t�@�C�����\��

			lstrcpy( pstDispInfo->item.pszText, rfstFileInfo.arcName.Left( nTextMax ) );
//			pstDispInfo->item.pszText = rfEnt[pstDispInfo->item.iItem].arcName.GetBuffer( 0 );
			break;

		case	6:
			// �J�n�A�h���X�\��

			_stprintf( pstDispInfo->item.pszText, _T("0x%x"), rfstFileInfo.start );
			break;

		case	7:
			// �I���A�h���X�\��

			_stprintf( pstDispInfo->item.pszText, _T("0x%x"), rfstFileInfo.end );
			break;
		}
	}
}

void CMainListView::ShowTip(LPNMLVGETINFOTIP ptip)
{
	static std::vector<SFileInfo>& pEnt = m_ent;

	switch (ptip->iSubItem) {
		case 0:
			// dwFlags��0�̂Ƃ�(�������B��Ă���Ƃ�)�ɕ\������
			// dwFlags��1�̂Ƃ��͕������B��Ă��Ȃ��Ƃ��ł���(���[�̃J�����͉B��Ă��Ȃ��Ƃ��ł��\�����Ă��܂�)
			if (ptip->dwFlags == 0)
				_stprintf(ptip->pszText, _T("%6d"), ptip->iItem + 1);
			break;
		case 1:
			lstrcpy(ptip->pszText, pEnt[ptip->iItem].name);
			break;
		case 2:
			lstrcpy(ptip->pszText, pEnt[ptip->iItem].sSizeOrg);
			break;
		case 3:
			if (pEnt[ptip->iItem].sizeCmp != pEnt[ptip->iItem].sizeOrg)
				lstrcpy(ptip->pszText, pEnt[ptip->iItem].sSizeCmp);
			break;
		case 4:
			lstrcpy(ptip->pszText, pEnt[ptip->iItem].format);
			break;
		case 5:
			lstrcpy(ptip->pszText, pEnt[ptip->iItem].arcName);
			break;
		case 6:
			_stprintf(ptip->pszText, _T("0x%x"), pEnt[ptip->iItem].start);
			break;
		case 7:
			_stprintf(ptip->pszText, _T("0x%x"), pEnt[ptip->iItem].end);
			break;
	}
}

// �\�[�g�p�̔�r�֐�
BOOL CMainListView::CompareFunc(const SFileInfo& a, const SFileInfo& b)
{
	static SORTPARAM* pSort = m_pSort;
	switch (pSort->column) {
		case 1:
			return (retCompare(a.name, b.name));
		case 2:
			return (retCompare(a.sizeOrg, b.sizeOrg));
		case 3:
			return (retCompare(a.sizeCmp, b.sizeCmp));
		case 4:
			return (retCompare(a.format, b.format));
		case 5:
			return (retCompare(a.arcName, b.arcName));
		case 6:
			return (retCompare(a.start, b.start));
		case 7:
			return (retCompare(a.end, b.end));
	}
	return FALSE;
}

// ���X�g�r���[���\�[�g����֐�
void CMainListView::OnSort()
{
	// No.���N���b�N���ꂽ��t���ɂ���
	if (m_sort.column == 0)
		std::reverse(m_ent.begin(), m_ent.end());
	else
		std::sort(m_ent.begin(), m_ent.end(), CompareFunc);
}

void CMainListView::Clear()
{
	std::vector<SFileInfo>& pEnt = m_ent;
	if (!pEnt.empty()) {
		// �擾�����t�@�C���������ׂď���
		for (int i = 0; i < (int)pEnt.size(); i++) {
			if (!pEnt[i].sizesOrg.empty()) {
				pEnt[i].sizesOrg.clear();
				pEnt[i].sizesCmp.clear();
				pEnt[i].starts.clear();
				pEnt[i].bCmps.clear();
			}
			pEnt[i].sTmpFilePath.clear();
		}
		pEnt.clear();
		// �\�����̃t�@�C���������ׂď���
		ListView_DeleteAllItems(m_hList);
		ListView_SetItemCountEx(m_hList, 0, LVSICF_NOINVALIDATEALL);
	}
}

//////////////////////////////////////////////////////////////////////////////////////////
//	�h���b�O���J�n���ꂽ

void	CMainListView::OnBeginDrag(
	NMHDR*				pNMHDR,
	LRESULT*			pResult
	)
{
	NM_LISTVIEW*		pNMListView = (NM_LISTVIEW*)pNMHDR;


}
