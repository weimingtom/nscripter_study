#pragma once

class CMzx {
public:
	void Decompress(LPBYTE dst, DWORD len, LPBYTE src);
};