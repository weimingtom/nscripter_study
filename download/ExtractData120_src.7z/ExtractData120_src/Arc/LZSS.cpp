
#include	"stdafx.h"
#include	"../Image.h"
#include	"LZSS.h"

//////////////////////////////////////////////////////////////////////////////////////////
//	�f�R�[�h

BOOL	CLZSS::Decode(
	CArcFile*			pclArc							// �A�[�J�C�u
	)
{
	SFileInfo*			pstFileInfo = pclArc->GetOpenFileInfo();

	if( pstFileInfo->format != _T("LZ") )
	{
		return	FALSE;
	}

	return	Decomp( pclArc, 4096, 4078, 3 );
}

//////////////////////////////////////////////////////////////////////////////////////////
//	�t�@�C���ɉ�

BOOL	CLZSS::Decomp(
	CArcFile*			pclArc,							// �A�[�J�C�u
	DWORD				dwDicSize,						// �����T�C�Y
	DWORD				dwDicPtr,						// ���������Q�ƈʒu
	DWORD				dwLengthOffset					// ��v���̃I�t�Z�b�g
	)
{
	SFileInfo*			pstFileInfo = pclArc->GetOpenFileInfo();

	// �ǂݍ���

	DWORD				dwSrcSize = pstFileInfo->sizeCmp;

	YCMemory<BYTE>		clmSrc( dwSrcSize );

	pclArc->Read( &clmSrc[0], dwSrcSize );

	// �𓀗p�o�b�t�@�̊m��

	DWORD				dwDstSize = pstFileInfo->sizeOrg;

	YCMemory<BYTE>		clmDst( dwDstSize );

	// ��

	Decomp( &clmDst[0], dwDstSize, &clmSrc[0], dwSrcSize, dwDicSize, dwDicPtr, dwLengthOffset );

	if( lstrcmp( PathFindExtension( pstFileInfo->name ), _T(".bmp") ) == 0 )
	{
		// �r�b�g�}�b�v

		CImage				clImage;

		clImage.Init( pclArc, &clmDst[0] );
		clImage.Write( dwDstSize );
		clImage.Close();
	}
	else
	{
		// ���̑�

		pclArc->OpenFile();
		pclArc->WriteFile( &clmDst[0], dwDstSize );
		pclArc->CloseFile();
	}

	return	TRUE;
}

//////////////////////////////////////////////////////////////////////////////////////////
//	�������ɉ�

BOOL	CLZSS::Decomp(
	void*				pvDst,							// �i�[��
	DWORD				dwDstSize,						// �i�[��T�C�Y
	const void*			pvSrc,							// ���k�f�[�^
	DWORD				dwSrcSize,						// ���k�f�[�^�T�C�Y
	DWORD				dwDicSize,						// �����T�C�Y
	DWORD				dwDicPtr,						// ���������Q�ƈʒu
	DWORD				dwLengthOffset					// ��v���̃I�t�Z�b�g
	)
{
	BYTE*				pbtDst = (BYTE*) pvDst;
	const BYTE*			pbtSrc = (const BYTE*) pvSrc;

	// �����o�b�t�@�̊m��

	YCMemory<BYTE>		clmbtDic( dwDicSize );

	ZeroMemory( &clmbtDic[0], dwDicSize );

	// ��

	DWORD				dwSrcPtr = 0;
	DWORD				dwDstPtr = 0;
	BYTE				btFlags;
	DWORD				dwBitCount = 0;

	while( (dwSrcPtr < dwSrcSize) && (dwDstPtr < dwDstSize) )
	{
		if( dwBitCount == 0 )
		{
			// 8bit�ǂݐ؂���

			btFlags = pbtSrc[dwSrcPtr++];
			dwBitCount = 8;
		}

		if( btFlags & 1 )
		{
			// �����k�f�[�^

			pbtDst[dwDstPtr] = clmbtDic[dwDicPtr] = pbtSrc[dwSrcPtr];

			dwDstPtr++;
			dwSrcPtr++;
			dwDicPtr++;

			dwDicPtr &= (dwDicSize - 1);
		}
		else
		{
			// ���k�f�[�^

			BYTE				btLow = pbtSrc[dwSrcPtr++];
			BYTE				btHigh = pbtSrc[dwSrcPtr++];

			DWORD				dwBack = (((btHigh & 0xF0) << 4) | btLow);
			DWORD				dwLength = ((btHigh & 0x0F) + dwLengthOffset);

			if( (dwDstPtr + dwLength) > dwDstSize )
			{
				// �o�̓o�b�t�@�𒴂��Ă��܂�

				dwLength = (dwDstSize - dwDstPtr);
			}

			for( DWORD j = 0 ; j < dwLength ; j++ )
			{
				pbtDst[dwDstPtr] = clmbtDic[dwDicPtr] = clmbtDic[dwBack];

				dwDstPtr++;
				dwDicPtr++;
				dwBack++;

				dwDicPtr &= (dwDicSize - 1);
				dwBack &= (dwDicSize - 1);
			}
		}

		btFlags >>= 1;
		dwBitCount--;


/*
		for( DWORD i = 0 ; (i < 8) && (dwSrcPtr < dwSrcSize) && (dwDstPtr < dwDstSize) ; i++ )
		{
			if( btFlags & 1 )
			{
				// �����k�f�[�^

				pbtDst[dwDstPtr] = clmbtDic[dwDicPtr] = pbtSrc[dwSrcPtr];

				dwDstPtr++;
				dwSrcPtr++;
				dwDicPtr++;

				dwDicPtr &= (dwDicSize - 1);
			}
			else
			{
				// ���k�f�[�^

				BYTE				btLow = pbtSrc[dwSrcPtr++];
				BYTE				btHigh = pbtSrc[dwSrcPtr++];

				DWORD				dwBack = (((btHigh & 0xF0) << 4) | btLow);
				DWORD				dwLength = ((btHigh & 0x0F) + dwOffset);

				if( (dwDstPtr + dwLength) > dwDstSize )
				{
					// �o�̓o�b�t�@�𒴂��Ă��܂�

					dwLength = (dwDstSize - dwDstPtr);
				}

				for( DWORD j = 0 ; j < dwLength ; j++ )
				{
					pbtDst[dwDstPtr] = clmbtDic[dwDicPtr] = clmbtDic[dwBack];

					dwDstPtr++;
					dwDicPtr++;
					dwBack++;

					dwDicPtr &= (dwDicSize - 1);
					dwBack &= (dwDicSize - 1);
				}
			}

			btFlags >>= 1;
		}*/
	}

	return	TRUE;
}
