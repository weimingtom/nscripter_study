
#include	"stdafx.h"
#include	"Common.h"
#include	"LastDir.h"

//////////////////////////////////////////////////////////////////////////////////////////
//	�R���X�g���N�^

CLastDir::CLastDir()
{
	LoadIni();
}

//////////////////////////////////////////////////////////////////////////////////////////
//	INI�t�@�C���̃��[�h

void	CLastDir::LoadIni()
{
	YCIni				clIni( SBL_STR_INI_EXTRACTDATA );

	clIni.SetSection( _T("LastDir") );

	clIni.SetKey( _T("LastReadFileDir") );
	clIni.ReadStr( m_szOpen, sizeof(m_szOpen), _T("") );
	clIni.SetKey( _T("LastSaveFolderDir") );
	clIni.ReadStr( m_szSave, sizeof(m_szSave), _T("") );
}

//////////////////////////////////////////////////////////////////////////////////////////
//	INI�t�@�C���ɕۑ�

void	CLastDir::SaveIni()
{
	YCIni				clIni( SBL_STR_INI_EXTRACTDATA );

	clIni.SetSection( _T("LastDir") );

	clIni.SetKey( _T("LastReadFileDir") );
	clIni.WriteStr( m_szOpen );
	clIni.SetKey( _T("LastSaveFolderDir") );
	clIni.WriteStr( m_szSave );
}

//////////////////////////////////////////////////////////////////////////////////////////
//	�Ō�ɊJ�����t�H���_�̎擾

LPTSTR	CLastDir::GetOpen()
{
	return	m_szOpen;
}

//////////////////////////////////////////////////////////////////////////////////////////
//	�Ō�ɕۑ������t�H���_�̎擾

LPTSTR	CLastDir::GetSave()
{
	return	m_szSave;
}
