
#include	"stdafx.h"
#include	"YCMemory.h"
