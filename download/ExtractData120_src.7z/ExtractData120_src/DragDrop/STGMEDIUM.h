#pragma once

class CSTGMEDIUM {
public:
	static BOOL Dup(STGMEDIUM* pdest, const FORMATETC* pFormatetc, const STGMEDIUM* pMedium);
};