#pragma once

class CBmpSearch : public CSearchBase {
public:
	CBmpSearch();
	void Mount(CArcFile* pclArc);
};