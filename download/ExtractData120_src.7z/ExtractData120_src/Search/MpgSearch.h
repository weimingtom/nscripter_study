#pragma once

class CMpgSearch : public CSearchBase {
public:
	CMpgSearch();
	void Mount(CArcFile* pclArc);
};