#include "stdafx.h"
#include "../SearchBase.h"
#include "MpgSearch.h"

CMpgSearch::CMpgSearch()
{
	InitHed("\x00\x00\x01\xBA\x21\x00\x01\x00", 8);
	InitFot("\xFF\xFF\xFF\xFF\x00\x00\x01\xB9", 8);
}

void CMpgSearch::Mount(CArcFile* pclArc)
{
	// ����C�Ȃ�CVM�ɑΉ�
	LPCTSTR pFileExt = (lstrcmpi(pclArc->GetArcExten(), _T(".cvm")) == 0) ? _T(".sfd") : _T(".mpg");

	SFileInfo infFile;

	// �J�n�A�h���X�擾
	infFile.start = pclArc->GetArcPointer();
	pclArc->Seek(GetHedSize(), FILE_CURRENT);
	pclArc->GetProg()->UpdatePercent(GetHedSize());

	// �t�b�^����
	if (SearchFot(pclArc) == FALSE)
		return;

	// �I���A�h���X�擾
	infFile.end = pclArc->GetArcPointer();

	// �t�@�C���T�C�Y�擾
	infFile.sizeOrg = infFile.end - infFile.start;
	infFile.sizeCmp = infFile.sizeOrg;

	pclArc->AddFileInfo(infFile, GetCtFile(), pFileExt);
}