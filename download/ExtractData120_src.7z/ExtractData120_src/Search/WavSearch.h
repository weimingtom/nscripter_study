#pragma once

class CWavSearch : public CSearchBase {
public:
	CWavSearch();
	void Mount(CArcFile* pclArc);
};