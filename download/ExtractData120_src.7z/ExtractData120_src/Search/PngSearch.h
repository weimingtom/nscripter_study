#pragma once

class CPngSearch : public CSearchBase {
public:
	CPngSearch();
	void Mount(CArcFile* pclArc);
};