#pragma once

class CAhxSearch : public CSearchBase {
public:
	CAhxSearch();
	void Mount(CArcFile* pclArc);
};