#pragma once

class CJpgSearch : public CSearchBase {
public:
	CJpgSearch();
	void Mount(CArcFile* pclArc);
};