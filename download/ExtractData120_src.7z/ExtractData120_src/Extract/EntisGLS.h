
#pragma		once

class	CEntisGLS : public CExtractBase
{
public:

	BOOL									Mount( CArcFile* pclArc );
	BOOL									Decode( CArcFile* pclArc );


protected:


};
