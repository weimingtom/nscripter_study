#pragma once

class CIzumo : public CExtractBase {
public:
	BOOL Mount(CArcFile* pclArc);
};