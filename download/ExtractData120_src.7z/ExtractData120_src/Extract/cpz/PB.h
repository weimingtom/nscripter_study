
#pragma	once

class CPB
{
public:

	BOOL									DecompLZSS( void* pvDst, DWORD dwDstSize, const void* pvFlags, DWORD dwFlagsSize, const void* pvSrc, DWORD dwSrcSize );
};
