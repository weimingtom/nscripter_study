#pragma once

class CAselia : public CExtractBase {
public:
	BOOL Mount(CArcFile* pclArc);
};