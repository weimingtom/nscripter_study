#include "stdafx.h"
#include "res/ResExtractData.h"
#include "ProgressBar.h"

extern BOOL g_bThreadEnd;

CProgBar::CProgBar()
{
	m_hDlg = NULL;
	m_hInst = NULL;
	m_percent = -1;
	m_ProgSize = 0;
}

CProgBar::~CProgBar()
{
}

void CProgBar::Init(HWND hDlg, QWORD AllFileSize)
{
	m_hDlg = hDlg;
	m_hInst = (HINSTANCE)GetWindowLongPtr(hDlg, GWLP_HINSTANCE);
	m_AllFileSize = AllFileSize;
	m_hDlgItem_percent = GetDlgItem(hDlg, IDC_PERCENT);
	m_hDlgItem_bar = GetDlgItem(hDlg, IDC_PROGBAR1);
	m_hDlgItem_archive = GetDlgItem(hDlg, IDC_EXTFILENAME);
	SendMessage(m_hDlgItem_bar, PBM_SETRANGE, (WPARAM)0, MAKELPARAM(0, 100));
	// 0%��\��
	UpdatePercent(0);
}

void CProgBar::ReplaceFileSize(QWORD oldFileSize, QWORD newFileSize)
{
	m_AllFileSize = m_AllFileSize - oldFileSize + newFileSize;
}

void CProgBar::ReplaceAllFileSize(QWORD newFileSize)
{
	m_AllFileSize += newFileSize;
}

// �p�[�Z���g���X�V����֐�
void CProgBar::UpdatePercent(QWORD BufSize)
{
	LPQWORD pProgSize = &m_ProgSize;
	*pProgSize += BufSize;
	int percent = (double)(*pProgSize) / m_AllFileSize * 100;
	if (percent > m_percent) {
		m_percent = percent;
		TCHAR percent_str[256];
		_stprintf(percent_str, _T("%3d%%"), percent);
		SetWindowText(m_hDlgItem_percent, percent_str);
		SendMessage(m_hDlgItem_bar, PBM_SETPOS, percent, 0);
	}
	if (OnCancel() == TRUE)
		throw -1;
}

// �p�[�Z���g��100%�ɍX�V����֐�
void CProgBar::UpdatePercent()
{
	UpdatePercent(m_AllFileSize - m_ProgSize);
}

void CProgBar::SetArcName(YCString& pclArcName)
{
	// �A�[�J�C�u�t�@�C�����\��
	SetWindowText(m_hDlgItem_archive, pclArcName);
}

void CProgBar::SetFileName(YCString& pFileName)
{
	// �t�@�C�����\��
	SetWindowText(m_hDlgItem_archive, pFileName);
}

// �L�����Z���������m�F����֐�
BOOL CProgBar::OnCancel()
{
	if (g_bThreadEnd)
		return TRUE;
	return FALSE;
}